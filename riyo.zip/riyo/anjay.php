<?php
// Dummy credentials for demonstration purposes
$credentials = [
    'administrator' => ['password' => 'admin123'],
    'petugas' => ['password' => 'petugas123'],
    'siswa' => ['password' => 'siswa123'],
];

// Initialize the session
session_start();

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $role = $_POST['role'];
    $password = $_POST['password'];

    if (isValidRole($role) && validateCredentials($role, $password)) {
        $_SESSION['user'] = $role;
        header("Location: index.php"); // Redirect to the main page after successful login
        exit();
    } else {
        $loginError = "Peran atau kata sandi tidak valid.";
    }
}

// Check if the provided role is valid
function isValidRole($role)
{
    return in_array($role, ['administrator', 'petugas', 'siswa']);
}

// Validate login credentials
function validateCredentials($role, $password)
{
    global $credentials;
    return isset($credentials[$role]) && $credentials[$role]['password'] === $password;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        form {
            display: inline-block;
            text-align: left;
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input {
            padding: 8px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            font-size: 14px;
            cursor: pointer;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2980b9;
        }

        .error {  
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Selamat datang di Halaman Login</h1>

    <form method="post" action="">
        <label for="role">Pilih Peran:</label>
        <select id="role" name="role" required>
            <option value="administrator">Administrator</option>
            <option value="petugas">Petugas</option>
            <option value="siswa">Siswa</option>
        </select><br>

        <label for="password">Kata Sandi:</label>
        <input type="password" id="password" name="password" required><br>

        <button type="submit" name="login">Login</button>
    </form>

    <?php if (isset($loginError)) : ?>
        <div class="error"><?php echo $loginError; ?></div>
    <?php endif; ?>
</body>
</html>