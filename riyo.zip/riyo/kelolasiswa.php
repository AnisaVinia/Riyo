<?php
// Dummy data for demonstration purposes
$students = [
    ['id' => 1, 'nama' => 'riyo febrianto'],
    ['id' => 2, 'nama' => 'rangga riski'],
    ['id' => 3, 'nama' => 'afandi'],
];

// Function to add a new student
function addStudent($nama)
{
    global $students;
    $newId = max(array_column($students, 'id')) + 1;
    $students[] = ['id' => $newId, 'nama' => $nama];
}

// Function to remove a student
function removeStudent($id)
{
    global $students;
    foreach ($students as $index => $student) {
        if ($student['id'] == $id) {
            unset($students[$index]);
            break;
        }
    }
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['addStudent'])) {
        $newStudentName = $_POST['newStudentName'];
        addStudent($newStudentName);
    } elseif (isset($_POST['removeStudent'])) {
        $studentIdToRemove = $_POST['studentIdToRemove'];
        removeStudent($studentIdToRemove);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Siswa</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        form {
            display: inline-block;
            text-align: left;
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input {
            padding: 8px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            font-size: 14px;
            cursor: pointer;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2980b9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #3498db;
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>Kelola Siswa</h1>

    <form method="post" action="">
        <label for="newStudentName">Tambahkan Siswa:</label>
        <input type="text" id="newStudentName" name="newStudentName" required>
        <button type="submit" name="addStudent">Tambahkan</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Siswa</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $student) : ?>
                <tr>
                    <td><?php echo $student['id']; ?></td>
                    <td><?php echo $student['nama']; ?></td>
                    <td>
                        <form method="post" action="">
                            <input type="hidden" name="studentIdToRemove" value="<?php echo $student['id']; ?>">
                            <button type="submit" name="removeStudent">Keluarkan</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>