<?php
// Inisialisasi data
$currentUser = null;
$credentials = array(
    'administrator' => array('password' => '123'),
    'petugas' => array('password' => '123')
);
$biodata = array();

function isValidRole($role) {
    return $role === 'administrator' || $role === 'petugas' || $role === 'siswa';
}

function isValidPassword($role, $password, $credentials) {
    return isset($credentials[$role]) && $credentials[$role]['password'] === $password;
}

function displayUserStatus($currentUser) {
    echo $currentUser ? "<p>Sedang login sebagai: $currentUser</p>" : '<p>Belum login</p>';
}

function showBiodataTable($biodata) {
    echo '<table id="biodata-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Agama</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>';
    $count = 1;
    foreach ($biodata as $data) {
        echo '<tr>
                <td>' . $count++ . '</td>
                <td>' . $data['nama'] . '</td>
                <td>' . $data['kelas'] . '</td>
                <td>' . $data['agama'] . '</td>
                <td>
                    <button onclick="editBiodata(' . $count . ')">Edit</button>
                    <button onclick="deleteBiodata(' . $count . ')">Hapus</button>
                </td>
            </tr>';
    }
    echo '</tbody></table>';
}

function hideBiodataTable() {
    echo '<style>#biodata-table {display: none;}</style>';
}

function hideBiodataForm() {
    echo '<style>#biodata-form {display: none;}</style>';
}

// ...
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Privilege</title>
    <style>
        /* Style CSS tetap sama */
    </style>
</head>
<body>
    <div id="content">
        <h1>Selamat datang di Aplikasi Privilege</h1>
        <div id="user-status">
            <?php displayUserStatus($currentUser); ?>
        </div>
        <button><a href="\riyooooo/anjay.php">login</a></button>
        <button><a href="\riyooooo/logout.php">Logout</a></button>
        <button><a href="\riyooooo/kelolasiswa.php">Kelola Siswa</a></button>
        <button><a href="\riyooooo/ubahkelas.php">Ubah Kelas</a></button>
        <button onclick="manageClasses()">Kelola Kelas</button>
        <button onclick="manageReligion()">Kelola Agama</button>

        <?php
        showBiodataTable($biodata);
        hideBiodataTable();
        hideBiodataForm();
        ?>

        <!-- Form Biodata -->
        <div id="biodata-form">
            <h2>Form Biodata</h2>
            <form id="biodata-form-content" action="" method="post">
                <label for="nama">Nama:</label>
                <input type="text" id="nama" name="nama" required><br>

                <label for="kelas">Kelas:</label>
                <input type="text" id="kelas" name="kelas" required><br>

                <label for="agama">Agama:</label>
                <input type="text" id="agama" name="agama" required><br>

                <button type="submit" name="submit">Simpan</button>
                <button type="button" onclick="cancelForm()">Batal</button>
            </form>
        </div>
    </div>
    <script>
        // ...
    </script>
</body>
</html>