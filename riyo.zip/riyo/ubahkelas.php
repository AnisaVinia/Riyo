<?php
// Dummy data for demonstration purposes
$classes = [
    ['id' => 1, 'nama' => 'XI RPL 2'],
    ['id' => 2, 'nama' => 'XI RPL 1'],
    ['id' => 3, 'nama' => 'XI KPR 2'],
];

// Function to add a new class
function addClass($nama)
{
    global $classes;
    $newId = max(array_column($classes, 'id')) + 1;
    $classes[] = ['id' => $newId, 'nama' => $nama];
}

// Function to update a class
function updateClass($id, $nama)
{
    global $classes;
    foreach ($classes as &$class) {
        if ($class['id'] == $id) {
            $class['nama'] = $nama;
            break;
        }
    }
}

// Function to remove a class
function removeClass($id)
{
    global $classes;
    foreach ($classes as $index => $class) {
        if ($class['id'] == $id) {
            unset($classes[$index]);
            break;
        }
    }
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['addClass'])) {
        $newClassName = $_POST['newClassName'];
        addClass($newClassName);
    } elseif (isset($_POST['updateClass'])) {
        $classIdToUpdate = $_POST['classIdToUpdate'];
        $updatedClassName = $_POST['updatedClassName'];
        updateClass($classIdToUpdate, $updatedClassName);
    } elseif (isset($_POST['removeClass'])) {
        $classIdToRemove = $_POST['classIdToRemove'];
        removeClass($classIdToRemove);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kelas</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        form {
            display: inline-block;
            text-align: left;
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input {
            padding: 8px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            font-size: 14px;
            cursor: pointer;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2980b9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #3498db;
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>Kelola Kelas</h1>

    <form method="post" action="">
        <label for="newClassName">Tambahkan Kelas:</label>
        <input type="text" id="newClassName" name="newClassName" required>
        <button type="submit" name="addClass">Tambahkan</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Kelas</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($classes as $class) : ?>
                <tr>
                    <td><?php echo $class['id']; ?></td>
                    <td><?php echo $class['nama']; ?></td>
                    <td>
                        <form method="post" action="">
                            <input type="hidden" name="classIdToUpdate" value="<?php echo $class['id']; ?>">
                            <input type="text" name="updatedClassName" placeholder="Nama Baru" required>
                            <button type="submit" name="updateClass">Ubah</button>
                        </form>
                        <form method="post" action="">
                            <input type="hidden" name="classIdToRemove" value="<?php echo $class['id']; ?>">
                            <button type="submit" name="removeClass">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>